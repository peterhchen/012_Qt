#include <QApplication>
#include <QHBoxLayout>
#include <QSlider>
#include <QSpinBox>

int main(int argc, char *argv[]) {
    QApplication prog(argc, argv);
    QWidget *mainWindow = new QWidget;
    mainWindow->setWindowTitle ("Main Window");
    QSpinBox *spinner = new QSpinBox;
    QSlider *slider = new QSlider (Qt::Horizontal);
    // We give spinner and slider the same range between (1, 50)
    spinner->setRange(1, 50);
    slider->setRange(1, 50);
    mainWindow->show();
    return prog.exec();
}
