#ifndef FINDCRAP_H
#define FINDCRAP_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class findcrap; }
QT_END_NAMESPACE

class findcrap : public QWidget
{
    Q_OBJECT

public:
    findcrap(QWidget *parent = nullptr);
    ~findcrap();

private slots:
    void on_pushButton_clicked();

private:
    Ui::findcrap *ui;
    void getTextFile();
};
#endif // FINDCRAP_H
