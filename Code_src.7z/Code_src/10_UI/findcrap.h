#ifndef FINDCRAP_H
#define FINDCRAP_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class findcrap; }
QT_END_NAMESPACE

class findcrap : public QWidget
{
    Q_OBJECT

public:
    findcrap(QWidget *parent = nullptr);
    ~findcrap();

private:
    Ui::findcrap *ui;
};
#endif // FINDCRAP_H
