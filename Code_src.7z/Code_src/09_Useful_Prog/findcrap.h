#ifndef FINDCRAP_H
#define FINDCRAP_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class findCrap; }
QT_END_NAMESPACE

class findCrap : public QWidget
{
    Q_OBJECT

public:
    findCrap(QWidget *parent = nullptr);
    ~findCrap();

private:
    Ui::findCrap *ui;
};
#endif // FINDCRAP_H
