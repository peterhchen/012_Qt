#include "findcrap.h"
#include "ui_findcrap.h"

findCrap::findCrap(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::findCrap)
{
    ui->setupUi(this);
}

findCrap::~findCrap()
{
    delete ui;
}

