#include <QApplication>
#include <QLabel>

int main(int argc, char *argv[]) {
    QApplication prog(argc, argv);
    QLabel *label = new QLabel("Gametime!");
    label->show(); // display lable widget on the screen.
    return prog.exec();
}
